run this under directory /dockermongodb

$ docker-compose -f docker-compose-mongodb.json up